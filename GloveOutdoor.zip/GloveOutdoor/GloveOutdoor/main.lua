updateData = 0
love.window.setMode( 381, 343, {resizable=true, vsync=0, minwidth=381, minheight=343, borderless=true})--, display=2, fullscreentype="desktop"}) --, borderless=true})
love.window.setIcon(love.image.newImageData("icon.png"))
love.window.setTitle("Glove Outdoor")
--txtimg = love.graphics.newImage("resources/Noto.png")
totaltimer={}
timer = 0
control = 0
resources = "resources"
showclock = 1
showpbar = 1
showfarol = 1
showsec=0
memtimer = 0
memfsize=0
function love.load()
  require("colors")
  lg = love.graphics
  la = love.window
  li = love.image
  lfs = love.filesystem
  console = os.execute
  fontfile = lfs.newFileData("NotoSans-Light.ttf")
  glovecache()
  appstatus="active"
  common()
  dir = lfs.getSaveDirectory( )
  foldexists=''
  foldexists=lfs.read("images/*.png")
  --foldexists=""..foldexists..lfs.read("images/*.jpg")
  --foldexists=""..foldexists..lfs.read("images/*.bmp")
  console("rm -rf images && ln -s "..dir.."/images .")
  subfolder = lfs.getInfo("GloveOUtdoor")
  --if subfolder ~= nil then
  console("rm -rf glove-outdoor-status && ln -s /tmp/glove-outdoor-status ./GloveOutdoor/")
  --end
  
  savedir = lfs.getSaveDirectory()
  
  wposx,wposy,displayn = la.getPosition()
  positioninfo=lfs.read("position.lua")
  if positioninfo == nil then
    windowmove(wposx,wposy,displayn)
    console("rm -rf  position.lua && ln -s "..savedir.."/position.lua .")
    if lfs.read("position.lua") ~= nil then
     require("position")
     la.setPosition(positionwindowx,positionwindowy,positionwindowd)
    end
  else
    require("position")
    la.setPosition(positionwindowx,positionwindowy,positionwindowd)
  end
  memW, memH = 0,0
  imgaddress = 0
  imgcontent = ''
  imgdata = ''
  imgx,imgy,imgow,imgoh,imgsw,imgsh,imgw,imgh = 0,0,0,0,0,0,0,0
  memimg = 0
  memFade,fadeval,stageFade,lockv,status,showstatus = 0,0,0,0,0,0
  timefade,fadetotal,proptime = 0,0,0
  blackboard=paint("black")
  effect = 1
  showname = 0
  imgison = 1
  fadein=0
  running="on"
end
function love.update(dt)
  common()
  --totaltimer[1] = lfs.read("glove-timer") or 0
  totaltimer[2] = tostring(lfs.read("glove-outdoor-status")) or 0
  --print(totaltimer[2])
  ctstt=0
  for str in string.gmatch(totaltimer[2], "([^%s]+)") do
    ctstt=ctstt+1
    if ctstt == 1 then if str == "on" then running="on";status="on" elseif str == "off" then status="off";running="off" end end
    if ctstt == 2 then if str ~= "0" then imgison = 1; imgaddress = str; content="image"; imagechange(); else content="emty"; imgison = 0 end end
    if ctstt == 3 then
     if str == "0" or str == nil or str == "black" then
     blackboard=paint("black") 
     else
     blackboard=paint(tostring(str))
     end
    end
    if ctstt == 4 then if str ~= "0" then effect=1 else effect=0 end end
    if ctstt == 5 then if str ~= "0" then showname=1 else showname=0 end end
    if ctstt > 5 then ctstt=0 end
    --print(str)
  end 
  appWidth, appHeight = la.getMode( )
  centerx = appWidth/2
  centery = appHeight/2
  runchange=(function()
    fontsystem = lg.setNewFont(fontfile, appHeight/20)
    resizeImage() 
  end)
  onWindowChange(runchange)
  imgx = centerx-(imgw/2)
  --if running == "off" then love.event.quit() end
  moveapp()
  savepositionapp()
  eFadeIn()
end
function love.draw(dt) 
  lg.setBackgroundColor(blackboard)
-- Image to view
  --if lockv == 0 then
  if imgison == 1 then img({1,1,1},imgdata,imgx,imgy,0,imgsw,imgsh) end
  if showname == 1 then
   write(paint("white"),imagename,centerx-fontsystem:getWidth(imagename),appHeight-fontsystem:getWidth(imagename))
  end
  --end
-- Fade Effect
  frame(fadecolor,0,0,appWidth,appHeight)
end

--[[ ######################################################################################################## ]]

function imagechange()
if memimg ~= imgaddress then
  memimg = imgaddress
  imgy=0
   os.execute("clear")
  if effect == 0 then
    fadein=0
  else fadein=700 end
  imagename = imgaddress
  --imagename = string.gsub(imagename,"image/","")
  print(imagename)
  imgcontent = li.newImageData(memimg)
  imgdata = lg.newImage(imgcontent)
  resizeImage()
end
end
function resizeImage()
  if content == "image" then
  imgow,imgoh = imgdata:getDimensions()
  imgsw,imgsh = getImageScaleForNewDimensions(imgdata, appWidth, appHeight)
  imgw,imgh = imgow*imgsw,imgoh*imgsh
  if imgh < appHeight then imgy=centery-(imgh/2) end
  print(imgw,imgh)
  end
end
function getImageScaleForNewDimensions( image, newWidth, newHeight )
    local currentWidth, currentHeight = image:getDimensions()
    print(appWidth,appHeight,newWidth, newHeight,currentWidth, currentHeight)
    if currentWidth < currentHeight then
     local reason = newHeight / currentHeight
     return  reason, reason
     
    elseif currentWidth > currentHeight then
     reasonIh=currentHeight/currentWidth
     reasonIw=currentWidth/currentHeight
     reasonA=newHeight/newWidth
     reasonW = newWidth / currentWidth
     reasonH = newHeight / currentHeight
     if (reasonIw*newWidth) > appHeight then
      return reasonW, newWidth/currentWidth
     elseif (reasonIw*newWidth) <= appHeight then
      return reasonW, reasonH
     end
     --return ( newWidth / currentWidth ), ( newHeight / currentHeight )
    elseif currentWidth == currentHeight then
     return ( newHeight / currentHeight ), ( newHeight / currentHeight )
    end
end

function love.keypressed(key)
  if key == "escape" then
    love.window.setFullscreen(false, "desktop")
    fullscreen = false
    love.window.setMode( 381, 343, {resizable=true, vsync=0, minwidth=381, minheight=343})
  end
  if key == "f11" then
    fullscreen = not fullscreen
    love.window.setFullscreen(fullscreen, "desktop")
  end
end


function glovecache()
  fadeval,fadetime,lockv = 0,0,0
  memW, memH = 0,0
end
function common()
 appWidth,appHeight=love.window.getMode( )
 centerx,centery=appWidth/2,appHeight/2
 wposx,wposy,displayn = la.getPosition()
 mousex, mousey = love.mouse.getX(dt), love.mouse.getY(dt)
 computertime = os.date('*t')
 sendStatus()
end
function eFadeIn()
 if fadein ~= 0 then
     if memFade == 0 then memFade = fadein end
     if fadein > 0 then fadein = fadein - 1 end
     if fadein == 0 then fadein = 0; end
     fadecolor=fadein/memFade
       --print(fadecolor,memFade,fadein)
     fadecolor={0,0,0,fadecolor}
 else
  if running == "off" and fadein == 0 then paint("desligando");appstatus="kill";sendStatus();love.event.quit() end
 end
end
function eFadeOut()
 if fadeout ~= 0 then
     local fadetime = tonumber(fadein)
     if memFade < fadeout then memFade = memFade + 1 end
     if memFade == fadeout then fadeout = 0; memFade = 0 ; end
     fadecolor=memFade/fadetime
       print(fadecolor,memFade,fadeout)
     fadecolor={0,0,0,fadecolor}
 end
end



function frame(k,a,b,c,d,r,s,sc)
  local k = k or {0,0,0,0}
  local a = a or 0
  local b = b or 0
  local c = c or 0
  local d = d or 0
  local radius = r or 0
  local s = s or 0
  local sc = sc or {0,0,0,.3}
  local unk = lg.setColor(k)
  local duni = lg.rectangle("fill", a, b, c, d, radius)
  local te = lg.rectangle("line", a, b, c, d, radius) --Line
   local qua = lg.setColor(sc) --Shadow
   local sad = 0
  if s ~= 0 then
   sad = lg.rectangle("line", a, b, c, d, radius, nil, nil, s) or "" --Shadow
  else sad = "" end
  return unk, duni, te, qua, sad
end
function write(k,t,a,b,f)
  local a = a or 0
  local b = b or 0
  local t = t or 0
  local k = k or {0,0,0}
  local f = f or fontsystem
  local uni = lg.setFont(f)
  local duni = lg.setColor(k)
  local te = lg.print(t, a, b)
  return uni, duni, te
end
--[[function cor(k)
  return lg.setColor(k)
end]]
function love.mousepressed(x, y, button, istouch)
  pressx,pressy=x,y
  if button == 1 then
    if type(execlick) == "function" then execlick() end
  end
end
function love.mousereleased( x, y, button, istouch, presses )
  pressx,pressy=0,0
  if button == 1 then
    if type(posexec) == "function" then posexec() end
    execlick = ""
  end
end
function img(k,i,x,y,r,sx,sy)
  local k = k or {1,1,1}
  local i = i or 0
  local x = x or 0
  local y = y or 0
  local r = r or 0
  local sx = sx or 0
  local sy = sy or 0
  if type(sx) == "table" then a = sx[1]; b = sx[2] else a = sx; b = sy end
  local uni = lg.setColor(k)
  local duni = lg.draw(i,x,y,r,a,b)
  return uni, duni
end
--[[ FUNÇÔES DE MOVIMENTO ]]
function moveapp()
--MOVE O APP COM O CURSOR DO MOUSE
  --[[ LOVE.UPDATE()
  --wposx,wposy,displayn = love.window.getPosition()
  --mousex, mousey = love.mouse.getX(dt), love.mouse.getY(dt)
  ]]
  if love.mouse.isDown(1) then
  execlick='0'
  local mMx,mMy = wposx,wposy
  local diff='' 
  if mousex < pressx then diff=pressx-mousex; mMx = mMx-diff; end
  if mousex > pressx then diff=mousex-pressx; mMx = mMx+diff; end
  if mousey < pressy then diff=pressy-mousey; mMy = mMy-diff; end
  if mousey > pressy then diff=mousey-pressy; mMy = mMy+diff; end
  love.mouse.setX(pressx);love.mouse.setY(pressy)
  love.window.setPosition(mMx,mMy,displayn)
  end
end
function savepositionapp()
  --put on LOVE.UPDATE
  local wposxc,wposyc,displaync = love.window.getPosition()
  if wposxc ~= wposx or wposyc ~= wposy or displaync ~= displayn then
   wposx,wposy,displayn = wposxc,wposyc,displaync
   windowmove(wposx,wposy,displayn)
  end
end

function windowmove(a,b,c)
  local config ="positionwindowx="..a.."\
positionwindowy="..b.."\
positionwindowd="..c
  love.filesystem.write( "position.lua", config)
end
function onWindowChange(a)
 local a = a or 0
 if memW ~= appWidth or memH ~= appHeight then 
  memW, memH = appWidth, appHeight
  if type(a) == "function" then a(); else print('String is empty') end
  --print(memW, memH)
 end
 a = ''
end
function sendStatus()
  os.execute("exec echo "..appstatus.." > /tmp/glove-outdoor-secoundscreen-status")
end
