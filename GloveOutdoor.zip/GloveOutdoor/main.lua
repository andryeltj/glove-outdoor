function love.load()
Classe = require("sys/classic")
require("sys/glove_simple")
gloveload()
require("sys/colors")
la.setIcon(li.newImageData("res/icon.png"))
la.setTitle("Glove Outdoor")
la.setMode( 380, 400, {resizable=true, vsync=0, minwidth=128, minheight=140})
require("tar/libs/setconfig")
updateSettingsParameters()
conffile = lfs.getInfo("conf.lua")
if conffile == nil then
 tbbtsettingsvalue[1]=1
 tbbtsettingsvalue[2]=1
 tbbtsettingsvalue[3]=0
 tbbtsettingsvalue[4]='black'
 tbbtsettingsvalue[5]=1
 tbbtsettingsvalue[6]=0
 tbbtsettingsvalue[7]=1
 tbbtsettingsvalue[8]=0
 updateConfig()
end
fontfile = lfs.newFileData("res/NotoSans-Light.ttf")
iconsmui = lfs.newFileData("res/mui-symbols.woff2")
appfontimg, appfontsize,appiconssize,appiconssize22,appiconssize32,appiconssize48,appiconssize96 = 9, 12, 16,22, 32,48, 82
appspacer = 2
margin = appspacer
linecolor = "rebeccapurple"
ctimages = 0
fontsystem = lg.setNewFont(fontfile, appfontsize)
fonttextimg = lg.setNewFont(fontfile, appfontimg)
fonticons = lg.setNewFont(iconsmui, appiconssize)
fonticons16 = lg.setNewFont(iconsmui, appfontsize)
fonticons22 = lg.setNewFont(iconsmui, appiconssize22)
fonticons32 = lg.setNewFont(iconsmui, appiconssize32)
fonticons48 = lg.setNewFont(iconsmui, appiconssize48)
fonticons96 = lg.setNewFont(iconsmui, appiconssize96)

require("tar/tasks")
mousearea=0
selected = 0

clickonplay=1

imagefile = 0 --Patch of image
bboard = "black" --Backgoud color name or RGB
bboardeffects = 1
bboardimgname = 0
bboardshowing = "off" -- Interruptor of secound screen
--[[windowMuda = (function()tbfloatbuttons = {}
 for i, v in ipairs(tbfloatbuttonsicon) do
   floatButtons:new(tbfloatbuttonsfx[i], tbfloatbuttonsicon[i],tbbtx[i], tbbty[1], appiconssize32/2,0,paint('rebeccapurple'),fonticons32,{.6,.3,.9,.01})
 end
 listImages()
--os.execute("exec love ./GloveOutdoor & fg")
 --listDisplay()
end)]]
dm=1
--require("conf.lua")
tasks:new()
--clear()
end
function love.update()
gloveupdate()
tasks:update()
gloveupdateEnds()
mouseAreaChange()
end
function love.draw()
tasks:draw()
--img({1,1,1},bkgd,0,0)
glovedraw()
--local w, h, flags = love.window.getMode()
--love.graphics.print(flags.display)

--lg.print(name,0,0)
write(paint("white"),bboardshowing.." "..imagefile.." "..bboard.." "..bboardeffects.." "..bboardimgname,0,256,fontsystem)
end
--[[ ######################################################################################### ]]
numdisplay=1
function listDisplay()
  local name = love.window.getDisplayCount( )--love.window.getDisplayName(numdisplay)
  --print(name)
  --if name ~= nil then numdisplay=numdisplay+1;listDisplay() end
end
function callDisplay()
  os.execute("exec love ./GloveOutdoor & fg")
end
memmid=0
function mouseAreaChange()
 if mousearea ~= memmid then memmid = mousearea; print("area",memmid) end
end

