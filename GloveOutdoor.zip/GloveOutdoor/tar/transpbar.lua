transpbar=Classe:extend()
function transpbar:new()
  fnumber = 256 --192
  fextend = 20 
  --imgframeres={}
  transpcommon()
end
function transpbar:update()
 transpcommon()
end
function transpbar:draw()
 for i=1, fnumber do
   tranplevelH = i/fnumber
   tranplevel = i/fnumber
   tranplevelimg = tranplevel/fextend
   --if tranplevelimg > 0.5 then tranplevelimg = 0 end
   By = (appHeight-barTranspY)+(barTranspY*tranplevelH)
   Bh = barTranspY-(barTranspY*tranplevelH)
   --print(fcolorname,tranplevel,tranplevelimg,By,appHeight, Bh)
   framek(paint(fcolorname,tranplevelimg),0,By,appWidth, Bh)
 end
end
function transpcommon()
 fcolorname = "black"
 barTranspY = barH*2
 execute=(function() mousearea=0;execlick="" end)
 if mousearea > 5 then eArea(execute,nil,0,appHeight-barTranspY,appWidth,barTranspY) end
 --print(barTranspY)
 --onWindowChange(function() callfade(fnumber,fextend) end)
end
