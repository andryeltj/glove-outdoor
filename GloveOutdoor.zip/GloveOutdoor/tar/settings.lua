settings=Classe:extend()
local utf8 = require("utf8")
function settings:new()
  require("tar/libs/settingsbuttons")
  tbbtsettingsfx = {}
  tbbtsettingsname = {"Darkmode","Play on click","Blackboard White","Blackboard background","Effect","Image name"}
  tbbtsettingsicon = {"","","","","",""}
  tbbtsettingsstatus = {"on","on","on","on","on","on"}
  tbbtsettingsvalue = {1,1,0,"black",1,0}
  tbbtsettingstype = {"bt","bt","bt","val","bt","bt"}
  tbbtsettingsfx[1]=(function() execlick=(function() print(1); if tbbtsettingsvalue[1] == 1 then tbbtsettingsvalue[1] = 0 else tbbtsettingsvalue[1] = 1 end; dm = tbbtsettingsvalue[1] end) end)
  tbbtsettingsfx[2]=(function() execlick=(function() print(2); if tbbtsettingsvalue[2] == 1 then tbbtsettingsvalue[2] = 0 else tbbtsettingsvalue[2] = 1 end end) end)
  tbbtsettingsfx[3]=(function() execlick=(function() print(3); if tbbtsettingsvalue[3] == 1 then tbbtsettingsvalue[3] = 0;tbbtsettingsstatus[4]="on" else tbbtsettingsvalue[3] = 1;tbbtsettingsstatus[4]="off" end end) end)
  tbbtsettingsfx[4]=(function() print(4);execlick='' end)
  tbbtsettingsfx[5]=(function() execlick=(function() print(5); if tbbtsettingsvalue[5] == 1 then tbbtsettingsvalue[5] = 0 else tbbtsettingsvalue[5] = 1 end end) end)
  tbbtsettingsfx[6]=(function() execlick=(function() print(6); if tbbtsettingsvalue[6] == 1 then tbbtsettingsvalue[6] = 0 else tbbtsettingsvalue[6] = 1 end end) end)
  myY=0
  runsetcommon()
  love.keyboard.setKeyRepeat(true)
end
function settings:update()
  runsetcommon()
  updateSettingsButtons()
end
function runsetcommon()
  sAreaX = (appWidth/10)
  sAreaY = (appHeight/10)
  sAreaW = appWidth-(appWidth/10)*2
  sAreaH = appHeight-(appHeight/10)*2
  sAreaR = margin*6
  sIareaW = (fonticons22:getWidth(tbbtsettingsicon[1]))+(margin*4)
  btAreaW = sAreaW
  btAreaH = (fontsystem:getWidth("A"))*4
  btflagW = btAreaH*2
  btflagH = btAreaH/1.5
  btflagX = sAreaX+sAreaW-(margin*2)-btflagW
  btSqW = (btflagW/3)
  backin = (function() execlick=(function() mousearea=0 end) end)
  if mousearea >= 5 then
    eArea(backin,nil,0,0,appWidth,sAreaY)
    eArea(backin,nil,0,sAreaY+sAreaH,appWidth,appHeight)
    eArea(backin,nil,0,sAreaY,sAreaX,sAreaY+sAreaH)
    eArea(backin,nil,sAreaX+sAreaW,sAreaY,appWidth,sAreaY+sAreaH)
  end  
  onWindowChange(function() buildbuttons() end)
  updateSettingsButtons()
end
function settings:draw()
if mousearea >= 5 then
framek({0,0,0,.6},0,0,appWidth,appHeight)
  framek(paint("grey900",0.95),sAreaX,sAreaY,sAreaW,sAreaH,sAreaR)
  --print(sAreaX)
  line(paint("grey700",0.1),sAreaX,sAreaY,sAreaW,sAreaH,sAreaR)
  drawSettingsButtons()
end    
end
function love.keypressed(key)
    if key == "backspace" then
        -- get the byte offset to the last UTF-8 character in the string.
        local byteoffset = utf8.offset(tbbtsettingsvalue[4], -1)

        if byteoffset then
            -- remove the last UTF-8 character.
            -- string.sub operates on bytes rather than UTF-8 characters, so we couldn't do string.sub(text, 1, -2).
            tbbtsettingsvalue[4] = string.sub(tbbtsettingsvalue[4], 1, byteoffset - 1)
        end
    end
end
function love.textinput(t)
    tbbtsettingsvalue[4] = tbbtsettingsvalue[4] .. t
end
function buildbuttons()
  tbsettingsbuttons = {}
  for k, text in ipairs(tbbtsettingsname) do
    if k == 1 then myY = sAreaY end
    settingsButtons(tbbtsettingsfx[k], text, tbbtsettingsicon[k], myY,tbbtsettingsstatus[k],tbbtsettingstype[k],tbbtsettingsvalue[k])
    myY = myY+btAreaH+margin
    print(k)
    end
end
