--Tasks windows
tasks = Classe:extend()
function tasks:new()
 require("tar/settings")
 require("tar/topbar")
 require("tar/floatbar")
 require("tar/mosaic")
 require("tar/transpbar")
 bkgdd=li.newImageData("res/circuit.png")
 bkgd=lg.newImage(bkgdd)
 szx,szy=0,0
 topbarh=fonticons:getHeight("")+(margin*4)
 hoverin=""
 settings:new()
 topbar:new()
 floatbar:new()
 mosaic:new()
 transpbar:new()
end
function tasks:update()
 onWindowChange(function() szx,szy=imageResize("fill",bkgd,appWidth,appHeight) end)
 topbar:update()
 mosaic:update()
 transpbar:update()
 floatbar:update()
 settings:update()
end
function tasks:draw()
 lg.draw(bkgd,0,0,0,szx,szy)
 mosaic:draw()
 topbar:draw()
 transpbar:draw()
 floatbar:draw()
 settings:draw()
end

