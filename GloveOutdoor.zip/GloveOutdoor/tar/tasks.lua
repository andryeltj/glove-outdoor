--Tasks windows
tasks = Classe:extend()
function tasks:new()
 require("tar/settings")
 require("tar/topbar")
 require("tar/floatbar")
 require("tar/mosaic")
 topbarh=fonticons:getHeight("")+(margin*4)
 hoverin=""
 settings:new()
 mosaic:new()
 topbar:new()
 floatbar:new()
end
function tasks:update()
 topbar:update()
 mosaic:update()
 floatbar:update()
 settings:update()
end
function tasks:draw()
 mosaic:draw()
 topbar:draw()
 floatbar:draw()
 settings:draw()
end

