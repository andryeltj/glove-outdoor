--drawFloatButtons=Classe:extend()
local class = require("sys/middleclass")
floatButtons = class("button")
tbfloatbuttons = {}
local originalFont = lg.getFont()
function floatButtons:initialize(code, text, btinfo, x, y, rx, ry, textColor, font, color)
self.code = code
self.text = text
self.btinfo = btinfo
self.mehover=0
self.x = x
self.y = y
self.rx = rx or 0
self.ry = ry or 0
self.textColor = textColor or {200,200,200}
self.font = font or love.graphics.getFont()
self.color = color or {150,150,150}
self.originalColor = self.color 
self.originaltextColor = self.textColor 
self.id = #tbfloatbuttons + 1
self.fx = fx
table.insert(tbfloatbuttons, self)
return self
end

--function floatButtons:draw()
function floatButtons:update()
    --print(self.x)
    hoverin=(function()
     	 execlick = self.code
     	 self.textColor=paint("#823EAC")
	 --self.color = {self.color[1] + 20, self.color[2] + 20, self.color[3] + 20,0.05}
	 self.color = paint("rebeccapurple",0.19)
	 --love.mouse.setCursor(hand)
	 --print(self.id)
	 self.mehover = 1
	 if bboardshowing == "on" then 
	   if self.id == 3 then self.btinfo=tbfloatbuttonsname[5]; end
	 else
	   if self.id == 3 then self.btinfo=tbfloatbuttonsname[3]; end
	 end
    end)
    
    hoverout=(function()
	 self.textColor = self.originaltextColor
	 self.color = self.originalColor
	 --love.mouse.setCursor()
	 self.mehover = 0
    end)
    if mousearea < 5 then eArea(hoverin, hoverout, self.x+(margin/2), self.y+(margin/8), self.font:getWidth(self.text)+margin, self.font:getWidth(self.text)+margin) end

end

function floatButtons:draw()
        if self.id == 2 then if bboardshowing == "on" then self.textColor=paint("white"); self.color = paint("rebeccapurple"); self.text = "" else self.text = ""; end end--self.textColor = self.originaltextColor; self.color = self.originalColor end end
	framek(self.color,self.x+(margin/2), self.y+(margin/8), self.font:getWidth(self.text)+margin, self.font:getWidth(self.text)+margin, self.rx)
	write(self.textColor,self.text, self.x+margin, self.y-(margin/2), self.font)
	
	lg.setColor(0.9,0.9,0.9,0.5)
	lg.setFont(originalFont)
	if self.mehover == 1 then
  framek(paint("white",.5),self.x+(margin/2),self.y-fontsystem:getHeight(self.btinfo)-(margin*2),fontsystem:getWidth(self.btinfo)+(margin*2),fontsystem:getHeight(self.btinfo)+margin)
  write(paint("black"),self.btinfo,self.x+(margin/2)+margin,self.y-fontsystem:getHeight(self.btinfo)-(margin*2))
 end
end

function updateFloatButtons()
 for i, v in pairs(tbfloatbuttons) do v:update() end 
end

function drawFloatButtons()
 for i, v in pairs(tbfloatbuttons) do v:draw() end 
end
