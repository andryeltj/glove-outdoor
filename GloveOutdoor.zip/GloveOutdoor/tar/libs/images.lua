local class = require("sys/middleclass")
images = class("button")
tbimages = {}
tbimagesX = {}
tbimagesY = {}
imga = ''
hoverframe, hovertext = '',''
showline = 0
showorder = 1
memidelement = 0
function images:initialize(patch, imgname, x, y)
  self.code = (function()
  if selected ~= self.id then
    selected=self.id
    imagefile = patch
    if clickonplay == 1 then
      if bboardshowing == "off" then bboardshowing = "on"; updateSetx(); callDisplay();end
    end
  else
    selected=0
    bboardshowing = "off"
  end
  updateSetx()
  --print(imgname)
  end)
  self.content = li.newImageData(patch)
  self.data = lg.newImage(self.content)
  self.name = imgname
  self.x,self.y = x or 0, y or 0
  imgow,imgoh = self.data:getDimensions()
  self.sw,self.sh = imageResize(self.data, imgW-(margin*5), imgH-(margin*5) )
  self.w,self.h = imgow*self.sw,imgoh*self.sh
  self.r = 12
  self.color = {0,0,0,0}
  self.textColor = paint("white")
  self.frameColor = {0,0,0,0}
  self.hoverColor = {0,0,0,.4}
  self.frameHoverColor = {0,0,0,.6}
  self.id = #tbimages + 1
  table.insert(tbimages, self)
  return self
end
function images:update()
  imgX = 0
  imgY = 120
  
  imgR = 12
  imga = self.data
  if mousearea == 3 then
   elhoverin = (function()
   self.frameColor = {1,1,1,.9}
   self.color = {.02,.55,.9}--{.8,.8,.8,.4}
   if selected == self.id then self.textColor = {0,0,0,.9} else self.textColor = paint("white") end
   --print("item",self.id)
   execlick=self.code
   --print(type(execlick))
   --checkselement(self.id)
   end)
   elhoverout= (function()
   self.color = {0,0,0,0}
   self.frameColor = {0,0,0,0}
   if selected == self.id then self.textColor = {0,0,0,.9} else self.textColor = paint("white") end
   end)
   --fiu=(function() self.x=xuni;self.y=xduni end)
   eArea(elhoverin,elhoverout,self.x,self.y,imgW,imgH+textHeight)
  end
  --print(type(execlick))
end
function images:draw()
 self.data:setFilter("nearest")
 if selected == self.id then
  framek(paint("orange"),self.x,self.y,imgW,imgH+textHeight,self.r) --{.02,.55,.9}
  img(paint("white"),self.data,(self.x+(imgW/2))-(self.w/2),(self.y+(imgH/2))-(self.h/2),0,self.sw,self.sh)
  write(paint("black",.45),"",self.x+(imgW/2)-(fonticons96:getWidth("")/2),self.y,fonticons96)
  write(paint("white",.8),"",self.x+(imgW/2)-(fonticons96:getWidth("")/2),self.y,fonticons96)
 else
  framek(self.color,self.x,self.y,imgW,imgH+textHeight,3)
  framek(paint("rebeccapurple"),self.x,self.y,imgW,imgH,self.r)
  img(paint("white"),self.data,(self.x+(imgW/2))-(self.w/2),(self.y+(imgH/2))-(self.h/2),0,self.sw,self.sh)
  if self.frameColor == {0,0,0,0} then
  write(paint("black",.45),"",self.x+(imgW/2)-(fonticons96:getWidth("")/2),self.y,fonticons96)
  end
  write(self.frameColor,"",self.x+(imgW/2)-(fonticons96:getWidth("")/2),self.y,fonticons96)
 end
 write(paint("black",.45),self.name,self.x+margin,self.y+imgH+margin,fonttextimg,imgW-(margin*2))
 write(self.textColor,self.name,self.x+margin,self.y+imgH+margin,fonttextimg,imgW-(margin*2))
 write(self.textColor,self.name,self.x+margin,self.y+imgH+margin,fonttextimg,imgW-(margin*2))
 if showorder == 1 then
 write({1,1,1},self.id,self.x+margin,self.y+margin,systemfont)
 end
 if showline == 1 then
  line(paint("white"),self.x,self.y,imgW,imgH+textHeight)
  line(paint("white"),lineposx,self.y,lineWidth,imgH+textHeight)
 end
end
--[[ ######################################################################################################## ]]


function getImageScaleForNewDimensions( image, newWidth, newHeight )
    local currentWidth, currentHeight = image:getDimensions()
    --print(appWidth,appHeight,newWidth, newHeight,currentWidth, currentHeight)
    if currentWidth < currentHeight then
     local reason = newHeight / currentHeight
     return  reason, reason
     
    elseif currentWidth > currentHeight then
     reasonIh=currentHeight/currentWidth
     reasonIw=currentWidth/currentHeight
     reasonA=newHeight/newWidth
     reasonW = newWidth / currentWidth
     reasonH = newHeight / currentHeight
     if (reasonIw*newWidth) > appHeight then
      return reasonW, newWidth/currentWidth
     elseif (reasonIw*newWidth) <= appHeight then
      return reasonW, reasonH
     end
     --return ( newWidth / currentWidth ), ( newHeight / currentHeight )
    elseif currentWidth == currentHeight then
     return ( newHeight / currentHeight ), ( newHeight / currentHeight )
    end
end


function updateImages()
 for i, v in pairs(tbimages) do v:update() end 
end
function drawImages()
 for i, v in pairs(tbimages) do v:draw() end 
end

function checkselement(a)
  if memidelement ~= a then memidelement = a; --print("image",memidelement)
  end
end
