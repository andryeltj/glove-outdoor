local class = require("sys/middleclass")
settingsButtons = class("button")
tbsettingsbuttons = {}
cursortime=0
cursorshow=1
local originalFont = lg.getFont()
function settingsButtons:initialize(code, text, icon, y,stt,tp,val)
self.code = code
self.text = text
self.icon = icon
self.x = sAreaX
self.y = y
self.status = stt
self.color = paint("black",0.3)
self.val = 0
self.tp = tp
self.id = #tbsettingsbuttons + 1
  table.insert(tbsettingsbuttons, self)
  return self
end
function settingsButtons:update()
  cursortime=cursortime+1
  if cursortime <= 3000 then cursorshow = 0 else cursorshow = 1; if cursortime >= 6000 then cursortime = 0 end end
  self.val = tbbtsettingsvalue[self.id]
  self.status = tbbtsettingsstatus[self.id]
  if self.status == "on" then
   self.val = tbbtsettingsvalue[self.id]
   if mousearea >= 5 then
   eventin=(function()
    self.code()
    self.color = paint("white",.03)
   end)
   eventout=(function()
    --execlick=''
    self.color = paint("black",0.3)
   end)
   eArea(eventin,eventout,self.x,self.y,sAreaW,btAreaH) end
  end
end
function settingsButtons:draw()
  framek(self.color,self.x,self.y,sAreaW,btAreaH)
   framek(paint("white",.03),self.x,self.y,sIareaW,btAreaH)
   if self.status == "on" then
   write(paint("white"),self.icon,self.x+(margin*2),self.y,fonticons22)
   write(paint("white"),self.text,self.x+sIareaW+(margin*2),self.y+margin,fontsystem)
   else
   write(paint("white",0.3),self.icon,self.x+(margin*2),self.y,fonticons22)
   write(paint("white",0.3),self.text,self.x+sIareaW+(margin*2),self.y+margin,fontsystem)
   end
   if self.tp == "val" then
    if self.status == "on" then
     framek(paint("white",0.5),btflagX,self.y+margin,btflagW,btflagH)
     write(paint("white"),self.val,btflagX+margin,self.y+margin)
    if cursorshow == 1 then write(paint("white"),"|",btflagX+margin+fontsystem:getWidth(self.val)-(fontsystem:getWidth("|")/3),self.y+margin) end
    else
     framek(paint("white",0.1),btflagX,self.y+margin,btflagW,btflagH)
     write(paint("blue"),self.val,btflagX+margin,self.y+margin)
    end
   elseif self.tp == "bt" then
    if self.val == 1 then
     framek(paint("rebeccapurple"),btflagX,self.y+margin,btflagW,btflagH)
     framek(paint("white"),btflagX+btflagW-btSqW,self.y+margin,btSqW,btflagH,3)
    else
     framek(paint("black",0),btflagX,self.y+margin,btflagW,btflagH)
     framek(paint("white"),btflagX,self.y+margin,btSqW,btflagH,3)
    end
   end
   if self.status == "on" then
    line(paint("white"),btflagX,self.y+margin,btflagW,btflagH,3,.1)
   else
    line(paint("white",0.3),btflagX,self.y+margin,btflagW,btflagH,3,.1)
   end
end

function updateSettingsButtons()
 for i, v in pairs(tbsettingsbuttons) do v:update() end 
end

function drawSettingsButtons()
 for i, v in pairs(tbsettingsbuttons) do v:draw() end 
end
