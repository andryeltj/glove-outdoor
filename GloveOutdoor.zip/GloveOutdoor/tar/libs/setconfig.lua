tbbtsettingsvalue={}
function updateSettingsParameters()
tbbtsettingsvalue[1]=tbbtsettingsvalue1
tbbtsettingsvalue[2]=tbbtsettingsvalue2
tbbtsettingsvalue[3]=tbbtsettingsvalue3
tbbtsettingsvalue[4]=tbbtsettingsvalue4
tbbtsettingsvalue[5]=tbbtsettingsvalue5
tbbtsettingsvalue[6]=tbbtsettingsvalue6
tbbtsettingsvalue[7]=tbbtsettingsvalue7
tbbtsettingsvalue[8]=tbbtsettingsvalue8
end
function updateConfig()
  --print("Config updated")
  local configContent=" tbbtsettingsvalue1="..tbbtsettingsvalue[1].."\n tbbtsettingsvalue2="..tbbtsettingsvalue[2].."\n tbbtsettingsvalue3="..tbbtsettingsvalue[3].."\n tbbtsettingsvalue4='"..tbbtsettingsvalue[4].."'\n tbbtsettingsvalue5="..tbbtsettingsvalue[5].."\n tbbtsettingsvalue6="..tbbtsettingsvalue[6].."\n tbbtsettingsvalue7="..tbbtsettingsvalue[7].."\n tbbtsettingsvalue8="..tbbtsettingsvalue[8].."\n selected="..selected
  lfs.write("conf.lua", configContent)
end