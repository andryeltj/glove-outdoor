floatbar=Classe:extend()
function floatbar:new()
 local areaid=4
 require("tar/libs/floatbuttons")
 tbfloatbuttonsicon={"","","",""}
 tbfloatbuttonsname={"Anterior","Exibir","Próximo","Ajustes","Parar"}
 tbfloatbuttonsfx={
 (function() Log(tbfloatbuttonsname[1]); self.textColor=paint("#A55ABF"); if selected <= 1 then selected = 1;imagefile=mosaicaddr[selected];updateSetx() else selected = selected - 1; imagefile=mosaicaddr[selected];updateSetx() end end),
 (function() Log(tbfloatbuttonsname[2]); self.textColor=paint("#A55ABF");
  if bboardshowing == "on" then bboardshowing ="off"; updateSetx();selected=0 
  else
    bboardshowing = "on"
    if selected == 0 then selected=1 end
    updateSetx()
    callDisplay()
  end end),
 (function() Log(tbfloatbuttonsname[3]); self.textColor=paint("#A55ABF"); if selected >= ctimages then selected = ctimages else selected = selected + 1; imagefile=mosaicaddr[selected]; updateSetx() end end),
 (function() Log(tbfloatbuttonsname[4]); self.textColor=paint("white");mousearea=5; end)
 }
 tbbtx={}
 tbbty={}
 margin=(appspacer*2)
 floatbarcommon()
end
function floatbar:update()
 updateFloatButtons()
 floatbarcommon()
end
function floatbarcommon()
 barW = (appiconssize32+appspacer)*table.getn(tbfloatbuttonsicon)+(margin*5.5)
 barH = appiconssize32+(appspacer*2)+margin
 barX = centerx-(barW/2)
 barY = appHeight-(barH/2)-barH-(appspacer*2)
 barR = barH/2
 cleararea=(function()
 mousearea=4
 hoverin=''
 end)
 if mousearea < 5 then eArea(cleararea,nil, barX,barY,barW,barH) end
 tbbtx[1],tbbty[1] = barX+(margin/2),barY+(margin/2)
 tbbtx[2],tbbty[2] = tbbtx[1]+appiconssize+(margin*5.5),tbbty[1]
 tbbtx[3],tbbty[3] = tbbtx[2]+appiconssize+(margin*5.5),tbbty[1]
 tbbtx[4],tbbty[4] = tbbtx[3]+appiconssize+(margin*5.5),tbbty[1]
 windowMuda = (function()
  tbfloatbuttons = {}
  for i, v in ipairs(tbfloatbuttonsicon) do
   floatButtons:new(tbfloatbuttonsfx[i], tbfloatbuttonsicon[i],tbfloatbuttonsname[i],tbbtx[i], tbbty[1], appiconssize32/2, 0, paint('rebeccapurple',0.5), fonticons32,{.6,.3,.9,.01})
  end
 end)
 onWindowChange(windowMuda)
end
function floatbar:draw()
framek({0,0,0,.9},barX,barY,barW,barH,barR)
 framek(paint("black",0.9),barX,barY,barW,barH,barR)
 --line(paint(linecolor),barX,barY,barW,barH,barR)
 drawFloatButtons()
end
