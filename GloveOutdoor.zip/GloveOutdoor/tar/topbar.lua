topbar=Classe:extend()
function topbar:new()
 topbarw = appWidth
 folderbt = {0,0,0,.03}
 folderbtOriginal = folderbt
 iconsw = fonticons:getWidth("")
 iinfo = 0
end
function topbar:update()
  insidetopbar=(function() execlick=''; mousearea = 1 end)
 if mousearea < 5 then 
  eArea(insidetopbar,nil,0,0,topbarw,topbarh)
  eArea(function()
   execlick = (function() love.system.openURL( "file://"..dir.."/images" ) end)
   folderbt = {1,1,1,.3}
   iinfo = 1
  end,function()
   folderbt = folderbtOriginal
   iinfo = 0
  end,appWidth-appiconssize-(margin*2),0,iconsw+(margin*2),iconsw+(margin*2))
end
  txtinfo = ctimages.." imagens"
end
function topbar:draw()
 framek(hex("#303030"),0,0,appWidth,topbarh)
 write(hex("#FFFFFF"),"",margin,margin,fonticons)
 framek(paint("#202020"),fonticons:getHeight()+(margin*2),margin,appWidth-((fonticons:getHeight()+(margin*2))*2),fonticons:getHeight(),12)
   write(hex("#FFFFFF"),"Display1",topbarh+(margin*2),fonticons:getHeight()-iconsw+(margin/2))
 framek(folderbt,appWidth-appiconssize-(margin*2),0,iconsw+(margin*2),iconsw+(margin*2),6)
 write(hex("#FFFFFF"),"",appWidth-appiconssize-margin,margin,fonticons)
 if iinfo == 1 then
  framek({1,1,1,.5},mousex-fontsystem:getWidth(txtinfo)-(margin*2),mousey-margin,fontsystem:getWidth(txtinfo)+margin,fontsystem:getHeight(txtinfo)+margin)
  write(paint("black"),txtinfo,mousex-fontsystem:getWidth(txtinfo)-margin,mousey)
 end
end
