mosaic=Classe:extend()
function mosaic:new()
 require("tar/libs/images")
 imageArray={}
 mum=''
 dir = lfs.getSaveDirectory( )
 foldexists=lfs.read("images/*.png")
  console("rm -rf images && ln -s "..dir.."/images .")
 tm = 0
 memlinex, memliney, memliner, ctimages, lines, numels = 0,0,0,0,1,0
 memlineWidth,textHeight = 0,0
 imgW,imgH = 96, 72
 mosaicposx = {}
 mosaicposy = {}
 mosaicaddr = {}
 mosaicname = {}
 lineWidth, centerAreaX = 0,0
 --[[  self.lineWidth, self.lines = fonttextimg:getWrap(self.name, imgW)
    for i, v in pairs(self.lines) do lines = lines+1 end
  self.lineHeight = lines*(fonttextimg:getHeight()+fonttextimg:getLineHeight())
  lines = 0
  --print(self.lineHeight)
  if self.lineHeight > textHeight then textHeight = self.lineHeight end
  local getx,gety = buildLine(id,margin,topbarh+margin,appWidth,appHeight-topbarh-margin,imgW,imgH,margin)
  memlinex, memliney, memliner = 0,0,0
  numitem = 0]]
end
function mosaic:update(dt)
 tm = (tm+1)
 mArea = {margin,topbarh+margin,appWidth-(margin*2),appHeight-topbarh-margin}
 centerAreaX = mArea[3]/2
 if tm == 3500 then tm=0; listImages() end
 updateImages()
end
function mosaic:draw()
 drawImages()
end
function love.filedropped(file)
	file:open("r")
	dir = lfs.getSaveDirectory( )
	local info = lfs.getInfo(dir)
	local svfolder = lfs.createDirectory("images")
	 if svfolder then
	  console("cp ".. file:getFilename() .." "..dir.."/images")
	 else
	  lfs.createDirectory("images")
	  console("cp ".. file:getFilename() .." "..dir.."/images")
	 end
	 filesinfo=''
	 listImages()
end
function listImages()
  tbimages = {};mosaicaddr = {};mosaicname={};mosaicposx = {};mosaicposy = {}
  memlinex, memliney, memliner, lines, ctimages, memlineWidth, kk,numels, textHeight= 0,0,0,0,0,0,1,0,0
  mosaicareax = appWidth-(margin*2)
  local folderimages = lfs.getDirectoryItems("images")
  for k, file in ipairs(folderimages) do
    ctimages = ctimages+1
    table.insert(mosaicaddr, "images/"..file)
    table.insert(mosaicname, file)
    nameHeight(file,imgW)
  end
  bdElements()
  for k, file in ipairs(mosaicaddr) do
    images(mosaicaddr[k],file,mosaicposx[k],mosaicposy[k])
  end
end
function bdElements()
  for k, file in ipairs(mosaicaddr) do
    itemw = imgW+margin
    memlinex = memlinex+itemw
    if memlinex > mosaicareax then
       lines = lines +1
       lineWidth = memlinex-itemw
       setx(numels)
       if lines <= 1 then
        memliney = mArea[2]
       else
        memliney = memliney+imgH+textHeight+margin
       end
       for i=1, numels do
        table.insert(mosaicposy,memliney)
       end
       
       memlinex,numels,kk = itemw,1,1
    else
      kk = kk+1
      if kk > numels then numels = numels +1 end
    end
    if k == table.getn(mosaicaddr) then
      setx(numels+1)
      memliney = memliney+imgH+textHeight
      table.insert(mosaicposy,memliney)
    end
    
  end
end
function setx(nms)
  local nms = nms
  lineposx = (mosaicareax/2)-(lineWidth/2)
  espc = lineWidth/nms
  memelspc = 0
  
  for i=1, nms do
    iposx = espc*i+lineposx
    cespc = iposx-(espc/2)
    pespc = cespc-(imgW/2)
    table.insert(mosaicposx,pespc)
  end
end
function nameHeight(name,w)
  local lineWidth, txlines = fonttextimg:getWrap(name, w)
  local qlines = 0
    for i, v in pairs(txlines) do qlines = i end
  local lineHeight = (qlines*(fonttextimg:getHeight()+fonttextimg:getLineHeight()))+margin
  if lineHeight > textHeight then textHeight = lineHeight; end
end
