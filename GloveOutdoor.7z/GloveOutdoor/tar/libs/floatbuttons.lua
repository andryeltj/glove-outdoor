--drawFloatButtons=Classe:extend()
local class = require("sys/middleclass")
floatButtons = class("button")
tbfloatbuttons = {}
local originalFont = lg.getFont()
function floatButtons:initialize(code, text, x, y, rx, ry, textColor, font, color)
self.code = code
self.text = text
self.x = x
self.y = y
self.rx = rx or 0
self.ry = ry or 0
self.textColor = textColor or {200,200,200}
self.font = font or love.graphics.getFont()
self.color = color or {150,150,150}
self.originalColor = self.color 
self.originaltextColor = self.textColor 
self.id = #tbfloatbuttons + 1
self.fx = fx
table.insert(tbfloatbuttons, self)
return self
end

--function floatButtons:draw()
function floatButtons:update()
    --print(self.x)
    hoverin=(function()
     	 execlick = self.code
     	 self.textColor={1,1,1,1}
	 --self.color = {self.color[1] + 20, self.color[2] + 20, self.color[3] + 20,0.05}
	 self.color = {.6,.3,.9,.3}
	 love.mouse.setCursor(hand)
	 --print(self.id)
    end)
    hoverout=(function()
	 self.textColor = self.originaltextColor
	 self.color = self.originalColor
	 love.mouse.setCursor()
    end)

    eArea(hoverin, hoverout, self.x+(margin/2), self.y+(margin/8), self.font:getWidth(self.text)+margin, self.font:getWidth(self.text)+margin)

end

function floatButtons:draw()
	framek(self.color,self.x+(margin/2), self.y+(margin/8), self.font:getWidth(self.text)+margin, self.font:getWidth(self.text)+margin, self.rx)
	write(self.textColor,self.text, self.x+margin, self.y-(margin/2), self.font)
	
	lg.setColor(0.9,0.9,0.9,0.5)
	lg.setFont(originalFont)
end

function updateFloatButtons()
 for i, v in pairs(tbfloatbuttons) do v:update() end 
end

function drawFloatButtons()
 for i, v in pairs(tbfloatbuttons) do v:draw() end 
end
