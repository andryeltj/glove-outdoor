quartcircle = math.pi / 2 -- Define 1/4 angle constant
function love.draw( )
  love.graphics.setColor( .7, .7, 1 ) -- Blueish color
  love.graphics.line( 200, 100, 600, 100 )
  love.graphics.line( 200, 300, 600, 300 )
  -- Angles are clockwise, as y value grows when going down 
  love.graphics.arc( "line", "open", 200, 200, 100, quartcircle, math.pi+quartcircle )
  love.graphics.arc( "line", "open", 600, 200, 100, -quartcircle, quartcircle)
end