updateData = 0
love.window.setMode( 381, 343, {resizable=true, vsync=0, minwidth=381, minheight=343})--, display=2, fullscreentype="desktop"}) --, borderless=true})
love.window.setIcon(love.image.newImageData("resources/icon2.png"))
love.window.setTitle("Glove Meeting Timer")
--txtimg = love.graphics.newImage("resources/Noto.png")
totaltimer={}
timer = 0
control = 0
resources = "resources"
showclock = 1
showpbar = 1
showfarol = 1
showsec=0
memtimer = 0
memfsize=0
function love.load()
  progressbar = {}
  timetop = {}
  timecenter = {}
  farois = {}
  lg = love.graphics
  lfs = love.filesystem
  console = os.execute
  totaltimer[1] = lfs.read("glove-timer") or 0
  totaltimer[2] = lfs.read("glove-timer-status") or 0
  fontfile = lfs.newFileData("elements/NotoSans-Bold.ttf")
  require("libs/colorize")
  clockfont=0
  fonttimersize = 0
  status=0
  cttime=0 --Para a barra de progresso(Qtd)
  toptime=0
  percent = 100
  localtime=0
  centertime=0
  centernum=" "
  centerctcolor = glove_theme_txt_color
  memftsize = 0
  fonttimertsize = 0
  clockfonttop = 0
  running = "on"
  memFade,fadeval,stageFade,lockv,showstatus = 0, 0, 0, 0, 0
  mousex,mousey,mMx,mMy = 0,0,0,0
  execlick,pressx,pressy,posexec = 0,0,0,''
  Ctfws,Ctfhs,secpart=0,0,' '
  
  savedir = lfs.getSaveDirectory()
  
  wposx,wposy,displayn = love.window.getPosition()
  positioninfo=lfs.read("position.lua")
  if positioninfo == nil then
    windowmove(wposx,wposy,displayn)
    console("rm -rf  position.lua && ln -s "..savedir.."/position.lua .")
    if lfs.read("position.lua") ~= nil then
     require("position")
     love.window.setPosition(positionwindowx,positionwindowy,positionwindowd)
    end
  else
    require("position")
    love.window.setPosition(positionwindowx,positionwindowy,positionwindowd)
  end
end
function love.update(dt)
  wposx,wposy,displayn = love.window.getPosition()
  mousex, mousey = love.mouse.getX(dt), love.mouse.getY(dt)
  totaltimer[1] = lfs.read("glove-timer") or 0
  totaltimer[2] = tostring(lfs.read("glove-timer-status")) or 0
  computertime = os.date('*t')
  if showsec == 1 then
   localtime = (computertime.hour*3600)+(computertime.min*60)+computertime.sec
  else
   localtime = (computertime.hour*60)+computertime.min
  end
  ctstt=0
  for str in string.gmatch(totaltimer[2], "([^%s]+)") do
    ctstt=ctstt+1
    if ctstt == 1 then if str ~= nil and cctime ~= tonumber(str) then cttime = tonumber(str) end end
    if ctstt == 2 then if str == "1" then status="on" else status="off" end end
    if ctstt == 3 then if str == "on" then running="on" else running="off" end end
    if ctstt == 4 then if str == "1" then showclock="1" else showclock="0" end end
    if ctstt == 5 then if str == "1" then showsec=1 else showsec=0 end end
    if ctstt == 6 then if str == "1" then showpbar="1" else showpbar="0" end end
    if ctstt == 7 then if str == "1" then showfarol="1" else showfarol="0" end end
    if ctstt > 7 then ctstt=0 end
  end
  if running == "off" then love.event.quit() end
  appWidth, appHeight = love.window.getMode( )
  centerx = appWidth/2
  centery = appHeight/2
  propx = appWidth/appHeight
  propy = appHeight/appWidth
  
  time = tonumber(totaltimer[1]) or 0
  if memtimer == time then timer = memtimer
  elseif time ~= 0 then memtimer = time; timer = memtimer
  end

  if status == "on" then
    eFade("500")
    percent = (memtimer*100)/cttime
    centertime=memtimer
    if memtimer < 31 and lockv == 0 then
     optA()
    else
    if lockv == 0 then
     optB()
     end
    end
    if memtimer < 1 and lockv == 0 then
     optC()
    end
    
  else
    centertime=localtime
    centerctcolor = glove_theme_txt_color
    eFade("500")
  end
--ADJUST FONTS
  fonttimersize = appWidth/3.5
  widthfonttitem=appWidth/8
  if (appHeight/4) < widthfonttitem then fonttimertsize = appHeight/4
  else fonttimertsize = widthfonttitem
  end
  if memfsize ~= fonttimersize then memfsize = fonttimersize
    clockfont = love.graphics.setNewFont(fontfile, fonttimersize)
    clockfontsec = love.graphics.setNewFont(fontfile, fonttimersize/1.6)
  end
  if memftsize ~= fonttimertsize then memftsize = fonttimertsize
    clockfonttop = love.graphics.setNewFont(fontfile, fonttimertsize)
  end
 
--PROGRESSBAR
  percent = percent/100
  pbw = (appWidth/3)+((appWidth/5)*2)
  pbh = appHeight/20
  pbx = centerx-(pbw/2)
  pby = appHeight/20
  pbr = pbh/2
  if lockv == 0 then pbpw = (pbw*percent)-2 end
  if timer < 0 then pbpw = 0 end
--TOP TIMER
  if showsec == 1 then
   hor = computertime.hour
   min = computertime.min
   sec = computertime.sec
   part = string.format("%02d:%02d.%02d",hor,min,sec)
  else
   hor = math.floor(localtime / 60)
   min = math.floor(localtime % 60)
   part = string.format("%02d:%02d",hor,min)
  end
  Ctfw=clockfonttop:getWidth(part)
  Ctfh=clockfonttop:getHeight(part)
  pfx = centerx-(Ctfw/2)
  pfy = centery-(centery/2)-(clockfonttop:getHeight(part)/2)-(appHeight/28)
  if lockv == 0 then toptime=part end
--CENTER TIMER
  if centertime < 0 then centertime=centertime*(-1) end
  if centertime > 3599 then
   horunits = math.floor(centertime / 3600)
   minunits = (math.floor(centertime / 60)%60)
   secunits = math.floor(centertime % 60)
   part = string.format("%02d:%02d",horunits,minunits)
   secpart = string.format(":%02d",secunits)
  else
   horunits = math.floor(centertime / 60)
   minunits = math.floor(centertime % 60)
   part = string.format("%02d:%02d",horunits,minunits)
  end
  Ctfw=clockfont:getWidth(part)
  Ctfh=clockfont:getHeight(part)
  if centertime > 3599 then
    Ctfws=clockfontsec:getWidth(secpart)
    Ctfhs=clockfontsec:getHeight(secpart)
  end
  if lockv == 0 then
    if showsec == 1 then
      cfx = centerx-(Ctfw/2)-(Ctfws/2)
      cfxs = cfx+Ctfw
      cfys = centery-(Ctfhs/3)
    else
      cfx = centerx-(Ctfw/2)
    end
  end
  cfy = centery-(Ctfh/2)
  if lockv == 0 then centernum=part end
--FAROIS
  gfh=(appHeight/4)/2
  fspace=(gfh/4)
  fw=gfh*2
  gfy=appHeight-gfh-fspace+(fspace/3)
  gfx=centerx-fw-fspace
  yfy=gfy
  yfx=centerx
  rfy=gfy
  rfx=centerx+fw+fspace
  
  moveapp()
  savepositionapp()
  
end

function love.keypressed(key)
  if key == "escape" then
    love.window.setFullscreen(false, "desktop")
    fullscreen = false
    love.window.setMode( 381, 343, {resizable=true, vsync=0, minwidth=381, minheight=343})
  end
  if key == "f11" then
    fullscreen = not fullscreen
    love.window.setFullscreen(fullscreen, "desktop")
  end
end

function love.draw(dt)
  if memfsize ~= fonttimersize then
     memfsize = fonttimersize
     clockfont = lg.setNewFont(fontfile, fonttimersize)
  end
  if memftsize ~= fonttimertsize then
     memftsize = fonttimertsize
     clockfonttop = lg.setNewFont(fontfilet, fonttimertsize)
  end 
  lg.setBackgroundColor(hex(glove_theme_bg_color))
if showstatus == 1 then
--Top Progressbar
  if showpbar == "1" then
    lg.setColor(hex(glove_theme_bt_hover_bg_color))
    lg.rectangle("fill",pbx,pby,pbw,pbh,pbr,pbr) --progressbackground
  lg.setColor(hex(centerctcolor))
  lg.rectangle("line",pbx,pby,pbw,pbh,pbr,pbr)
    if memtimer > 0 then
    lg.setColor(hex(glove_theme_txt_color))
    lg.rectangle("line",pbx+2,pby+2,pbpw,pbh-4,pbr,pbr)
    lg.rectangle("fill",pbx+2,pby+2,pbpw,pbh-4,pbr,pbr) --progress
    end
  end
--Time top
  if showclock == "1" then
  write(hex(glove_theme_txt_color),toptime,pfx,pfy,clockfonttop)
  end
  if showfarol == "1" then
--Farol Verde
  lg.setColor(hex(ringgreen))
  lg.circle("line",gfx,gfy,gfh,360)
    lg.setColor(hex(fargreen))
    lg.circle("fill",gfx,gfy,gfh,360)
--Farol Laranja
  lg.setColor(hex(ringorange))
  lg.circle("line",yfx,yfy,gfh,360)
    lg.setColor(hex(farorange))
    lg.circle("fill",yfx,yfy,gfh,360)
--Farol Vermelho
  lg.setColor(hex(ringred))
  lg.circle("line",rfx,rfy,gfh,360)
    lg.setColor(hex(farred))
    lg.circle("fill",rfx,rfy,gfh,360)
  end
end
--Localtime
   write(hex(centerctcolor),centernum,cfx,cfy,clockfont)
   if showsec == 1 then write(hex(centerctcolor),secpart,cfxs,cfys,clockfontsec) end
--Fade Effect
   frame(fadecolor,0,0,appWidth,appHeight)
end

function optA()
 centerctcolor = display_color_yellow
 ringgreen = glove_theme_txt_color
 ringorange = display_color_yellow_stop
 ringred = glove_theme_txt_color
 fargreen = display_color_green_stop
 farorange = display_color_yellow
 farred = display_color_red_stop
end
function optB()
 centerctcolor = display_color_green
 ringgreen = display_color_green
 ringorange = glove_theme_txt_color
 ringred = glove_theme_txt_color
 fargreen = display_color_green
 farorange = display_color_yellow_stop
 farred = display_color_red_stop
end
function optC()
 centerctcolor = display_color_red
 ringgreen = glove_theme_txt_color
 ringorange = glove_theme_txt_color
 ringred = display_color_red_stop
 fargreen = display_color_green_stop
 farorange = display_color_yellow_stop
 farred = display_color_red
end

function eFade(a)
    if status ~= memFade then
     local fadetime = tonumber(a)
     fadetime=fadetime/2
     if fadeval > fadetime and stageFade == 0 or fadeval == fadetime then
      fadeval = fadetime; stageFade=1;lockv = 0
     elseif fadeval < fadetime and stageFade == 0 then lockv=1; fadeval=fadeval+1 end
     if stageFade == 1 then
      fadeval=fadeval-1
      if fadeval > 0 then fadeval = 0; stageFade = 0; memFade = status; end
     end
     
     
  if lockv == 0 then
    --Put "if lockv == 1 then" in all functions on value is exhibit and colors are changed inside LOVE.UPDATE()
    if status == "on" then showstatus = 1 end
    if status == "off" then showstatus = 0 end 
  end
     
     fadecolor=fadeval/fadetime
     fadecolor={0,0,0,fadecolor}
    --os.execute("clear")
     --print(status,memFade,fadeval,stageFade)
    end
end



function frame(k,a,b,c,d,r,s,sc)
  local k = k or {0,0,0,0}
  local a = a or 0
  local b = b or 0
  local c = c or 0
  local d = d or 0
  local radius = r or 0
  local s = s or 0
  local sc = sc or {0,0,0,.3}
  local unk = lg.setColor(k)
  local duni = lg.rectangle("fill", a, b, c, d, radius)
  local te = lg.rectangle("line", a, b, c, d, radius) --Line
   local qua = lg.setColor(sc) --Shadow
   local sad = 0
  if s ~= 0 then
   sad = lg.rectangle("line", a, b, c, d, radius, nil, nil, s) or "" --Shadow
  else sad = "" end
  return unk, duni, te, qua, sad
end
function write(k,t,a,b,f)
  local a = a or 0
  local b = b or 0
  local t = t or 0
  local k = k or {0,0,0}
  local f = f or fontsystem
  local uni = lg.setFont(f)
  local duni = lg.setColor(k)
  local te = lg.print(t, a, b)
  return uni, duni, te
end
function cor(k)
  return lg.setColor(k)
end
function love.mousepressed(x, y, button, istouch)
  pressx,pressy=x,y
  if button == 1 then
    if type(execlick) == "function" then execlick() end
  end
end
function love.mousereleased( x, y, button, istouch, presses )
  pressx,pressy=0,0
  if button == 1 then
    if type(posexec) == "function" then posexec() end
    execlick = ""
  end
end
--[[ FUNÇÔES DE MOVIMENTO ]]
function moveapp()
--MOVE O APP COM O CURSOR DO MOUSE
  --[[ LOVE.UPDATE()
  --wposx,wposy,displayn = love.window.getPosition()
  --mousex, mousey = love.mouse.getX(dt), love.mouse.getY(dt)
  ]]
  if love.mouse.isDown(1) then
  execlick='0'
  local mMx,mMy = wposx,wposy
  local diff='' 
  if mousex < pressx then diff=pressx-mousex; mMx = mMx-diff; end
  if mousex > pressx then diff=mousex-pressx; mMx = mMx+diff; end
  if mousey < pressy then diff=pressy-mousey; mMy = mMy-diff; end
  if mousey > pressy then diff=mousey-pressy; mMy = mMy+diff; end
  love.mouse.setX(pressx);love.mouse.setY(pressy)
  love.window.setPosition(mMx,mMy,displayn)
  end
end
function savepositionapp()
  --put on LOVE.UPDATE
  local wposxc,wposyc,displaync = love.window.getPosition()
  if wposxc ~= wposx or wposyc ~= wposy or displaync ~= displayn then
   wposx,wposy,displayn = wposxc,wposyc,displaync
   windowmove(wposx,wposy,displayn)
  end
end
function windowmove(a,b,c)
  local config ="positionwindowx="..a.."\
positionwindowy="..b.."\
positionwindowd="..c
  love.filesystem.write( "position.lua", config)
end
