function gloveload()
  scrolls = {}
  lg = love.graphics
  la = love.window
  li = love.image
  lfs = love.filesystem
  hand = love.mouse.getSystemCursor("hand")
  console = os.execute
  varnamessets()
  --glovecache()
  common()
  --onWindowChange(a)
end
function gloveupdate()
  common()
end
function varnamessets()
  --line = "line"
  fill = "fill"
  execlick=''
end
function glovecache()
  fadeval,fadetime,lockv = 0,0,0
  memW, memH = 0,0
end
function common()
 appWidth,appHeight=love.window.getMode( )
 centerx,centery=appWidth/2,appHeight/2
 wposx,wposy,displayn = la.getPosition()
 mousex, mousey = love.mouse.getX(dt), love.mouse.getY(dt)
 computertime = os.date('*t')
end

function checkConfFile(mainfilepath)
savedir = lfs.getSaveDirectory()
local file = "conf"
confFile=lfs.read(file)
 if confFile == nil then
  local config=lfs.newFileData(mainfilepath)
  lfs.write(file..".lua", config)
  console("rm -rf "..file.." && ln -s "..savedir.."/"..file..".lua")
  if lfs.read(file..".lua") ~= nil then require(file) end
 else require(conf)
 end
end

function eFade(a)
 if status ~= memFade then
     local fadetime = tonumber(a)
     fadetime=fadetime/2
     if fadeval > fadetime and stageFade == 0 or fadeval == fadetime then
      fadeval = fadetime; stageFade=1;lockv = 0
     elseif fadeval < fadetime and stageFade == 0 then lockv=1; fadeval=fadeval+1 end
     if stageFade == 1 then
      fadeval=fadeval-1
      if fadeval > 0 then fadeval = 0; stageFade = 0; memFade = status; end
     end
     
     
  if lockv == 0 then
    --Put "if lockv == 1 then" in all functions on value is exhibit and colors are changed inside LOVE.UPDATE()
    if status == "on" then showstatus = 1 end
    if status == "off" then showstatus = 0 end 
  end
     fadecolor=fadeval/fadetime
     fadecolor={0,0,0,fadecolor}
 end
end
memW, memH = 0,0
function onWindowChange(a)
 local a = a or 0
 if memW ~= appWidth or memH ~= appHeight then 
  memW, memH = appWidth, appHeight
  if type(a) == "function" then a(); else print('String is empty') end
  --print(memW, memH)
 end
 a = ''
end
function eScroll(exec,idname,xs,ys,xe,ye,varweightX,varweightY)
  --EXECUTES IF INSIDE XYWH AREA OF ELEMENT
  self.exec, self.idname, self.xs, self.ys, self.xe, self.ye, self.id = exec or nil, idname or nil, xs or 0,  ys or 0, xe or 0,  ye or 0, #scrolls + 1
  local varweightX,varweightY = varweightX..tostring() or 0, varweightY..tostring() or 0
 if rolly > 0 or rolly < 0 then
  --#scrolls = {}
  table.insert(scrolls, self)
  local diffx, diffy = xe-xs, ye-ys
  if type(self.exec) == "function" then self.exec() end
 end 
end
local mousememX, mousememY = 0,0
function eArea(execin,execout,a,b,c,d)
  local execin = execin or 0
  local execout = execout or 0
  local a, b, c, d = a or 0, b or 0, c or 0, d or 0
 --if mousex ~= mousememX or mousey ~= mousememY then
  --mousememX, mousememY = mousex, mousey
  --print(execin,execout,a,b,c,d)
  if  mousex > a and mousey > b
  and mousex < (a+c) and mousey < (b+d) then
    if type(execin) == "function" then execin() end
  else
    if type(execout) == "function" then execout() end
  end
 --end
end

function screenSliceW(n)
 return appWidth/n
end
function screenSliceH(n)
 return appHeight/n
end
function elementSliceW(n,a,b)
 local element=b-a
 return element/n
end
function elementSliceH(n,a,b)
 local element=b-a
 return element/n
end
function elementCenterW(a,b)
 local element=b-a
 return element/2
end
function elementCenterH(a,b)
 local element=b-a
 return element/2
end
function percent(a,b,c)
 local a = a or 0
 local b = b or 100
 local x = (b-a)/c
 return x
end
function rulethree(a,b,d)
--	A	=	B
--	X	=	D
 local x = (a*d)/b
 return x
end

function line(k,a,b,c,d,r)
  local k = k or {0,0,0,0}
  local a = a or 0
  local b = b or 0
  local c = c or 0
  local d = d or 0
  local radius = r or 0
  local unk = lg.setColor(k)
  local duni = lg.setLineWidth(1)
  local te = lg.rectangle("line", a, b, c, d, radius)
  return unk, duni, te
end
function framek(k,a,b,c,d,r)
  local unk = lg.setColor(k)
  local duki = lg.setLineWidth(0.5)
  local duni = lg.rectangle("fill", a, b, c, d,r)
  local te = lg.rectangle("line", a, b, c, d,r) --Line
  return unk, duki, duni, te
end
function frame(k,a,b,c,d,r,s,sc)
  local k = k or {0,0,0,0}
  local a = a or 0
  local b = b or 0
  local c = c or 0
  local d = d or 0
  local radius = r or 0
  local s = s or 0
  local sc = sc or {0,0,0,.3}
  local unk = lg.setColor(k)
  local duni = lg.rectangle("fill", a, b, c, d, radius)
  local te = lg.rectangle("line", a, b, c, d, radius) --Line
  --[[ local qua = lg.setColor(sc) --Shadow
   local sad = 0
  if s ~= 0 then
   sad = lg.rectangle("line", a, b, c, d, radius, nil, nil, s) or "" --Shadow
  else sad = "" end
  ]]
  return unk, duni, te--, qua, sad
end
function write(k,t,a,b,f,l,j)
  local a = a or 0
  local b = b or 0
  local t = t or 0
  local k = k or {0,0,0}
  local f = f or fontsystem
  f:setFilter("nearest","nearest")
  local l  = l or f:getWidth(t)
  local j = j or "center"
  local uni = lg.setFont(f)
  local duni = lg.setColor(k)
  local te = lg.printf(t, a, b, l)
  
  return uni, duni, te
end
function cor(k)
  return lg.setColor(k)
end
function img(k,i,x,y,r,sx,sy)
  local k = k or {1,1,1}
  local i = i or 0
  local x = x or 0
  local y = y or 0
  local r = r or 0
  local sx = sx or 0
  local sy = sy or 0
  if type(sx) == "table" then a = sx[1]; b = sx[2] else a = sx; b = sy end
  local uni = lg.setColor(k)
  local duni = lg.draw(i,x,y,r,a,b)
  return uni, duni
end
function love.mousepressed(x, y, button, istouch)
  --print("clicked",type(execlick))
  pressx,pressy=x,y
  if button == 1 then
    if type(execlick) == "function" and execlick ~= nil then execlick() end
  end
end
function love.mousereleased( x, y, button, istouch, presses )
  --print("unclicked",execlick)
  pressx,pressy=0,0
  if button == 1 then
    if type(posexec) == "function" then posexec() end
   execlick = ""
  end
end
--[[ FUNÇÔES DE MOVIMENTO ]]
function moveapp() --onchangepositionwindow
--MOVE O APP COM O CURSOR DO MOUSE
  --[[ LOVE.UPDATE()
  --wposx,wposy,displayn = love.window.getPosition()
  --mousex, mousey = love.mouse.getX(dt), love.mouse.getY(dt)
  ]]
  if love.mouse.isDown(1) then
  execlick=''
  local mMx,mMy = wposx,wposy
  local diff='' 
  if mousex < pressx then diff=pressx-mousex; mMx = mMx-diff; end
  if mousex > pressx then diff=mousex-pressx; mMx = mMx+diff; end
  if mousey < pressy then diff=pressy-mousey; mMy = mMy-diff; end
  if mousey > pressy then diff=mousey-pressy; mMy = mMy+diff; end
  love.mouse.setX(pressx);love.mouse.setY(pressy)
  love.window.setPosition(mMx,mMy,displayn)
  end
end
function savepositionapp()
  --put on LOVE.UPDATE
  local wposxc,wposyc,displaync = love.window.getPosition()
  if wposxc ~= wposx or wposyc ~= wposy or displaync ~= displayn then
   wposx,wposy,displayn = wposxc,wposyc,displaync
   windowmove(wposx,wposy,displayn)
  end
end
function windowmove(a,b,c)
  local config ="positionwindowx="..a.."\
positionwindowy="..b.."\
positionwindowd="..c
  lfs.write( "position.lua", config)
end

function Log(a)
  print(a)
end
function LogClear(a)
  console("clear")
  print(a)
end
function clear() console("clear") end
