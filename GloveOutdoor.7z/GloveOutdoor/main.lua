function love.load()
Classe = require("sys/classic")
require("sys/glove_simple")
gloveload()
require("sys/colors")
la.setIcon(li.newImageData("res/icon.png"))
la.setTitle("Glove Outdoor")
la.setMode( 380, 400, {resizable=true, vsync=0, minwidth=128, minheight=140})
fontfile = lfs.newFileData("res/NotoSans-Light.ttf")
iconsmui = lfs.newFileData("res/mui-symbols.woff2")
appfontimg, appfontsize,appiconssize,appiconssize32,appiconssize96 = 9, 12, 16, 32, 96
appspacer = 2
margin = appspacer
linecolor = "rebeccapurple"
ctimages = 0
fontsystem = lg.setNewFont(fontfile, appfontsize)
fonttextimg = lg.setNewFont(fontfile, appfontimg)
fonticons = lg.setNewFont(iconsmui, appiconssize)
fonticons32 = lg.setNewFont(iconsmui, appiconssize32)
fonticons96 = lg.setNewFont(iconsmui, appiconssize96)
require("tar/tasks")
windowMuda = (function()tbfloatbuttons = {}
 for i, v in ipairs(tbfloatbuttonsicon) do
   floatButtons:new(tbfloatbuttonsfx[i], tbfloatbuttonsicon[i],tbbtx[i], tbbty[1], appiconssize32/2,0,paint('rebeccapurple'),fonticons32,{.6,.3,.9,.01})
 end
 listImages()
end)
tasks:new()
clear()
end
function love.update()
gloveupdate()
tasks:update()
onWindowChange(windowMuda)
end
function love.draw()
tasks:draw()
end
